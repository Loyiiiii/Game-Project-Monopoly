export module propertyinfo;
import <cstddef>;

export struct PropertyInfo {
    size_t buildingIndex;
    int improveLevel;
    int monopolyValue;
};
