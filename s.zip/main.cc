import <iostream>;
import <cstddef>;
import <string>;
import <vector>;
import square;
import property;
import non_property;
import academic;
import gyms;
import residence;
import osap;
import goose_nesting;
import tuition;
import coop_fee;
import slc;
import nh;
import gototims;
import dctimsline;
using namespace std;

int main() {
    Square* s = new Academic(11);
    cout << s->getImprovementCost(11) << endl;
    delete s;
}
